import React from 'react';

export const a = () => {
  return <h1>A</h1>;
};
export const b = () => {
  return <h1>B</h1>;
};
export const c = 5;

// {a,b,c}
