import React from 'react';


// jsx
const App = () => {
  return <h1>MERAKI Academy</h1>;
};

export default App